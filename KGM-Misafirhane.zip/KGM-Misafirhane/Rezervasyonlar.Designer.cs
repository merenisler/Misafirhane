﻿namespace KGM_Misafirhane
{
    partial class rezervasyonlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rezervasyonlar));
            bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(components);
            btnCikis = new Button();
            ımageList2 = new ImageList(components);
            btnImg = new Button();
            ımageList1 = new ImageList(components);
            btnOdalar = new Button();
            btnRaporlar = new Button();
            btnRezervasyonlar = new Button();
            btnOnayBekleyen = new Button();
            btnOnaylanan = new Button();
            btnGecmis = new Button();
            lstViewRezervasyonlar = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            columnHeader6 = new ColumnHeader();
            columnHeader7 = new ColumnHeader();
            columnHeader8 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader9 = new ColumnHeader();
            columnHeader10 = new ColumnHeader();
            columnHeader11 = new ColumnHeader();
            columnHeader14 = new ColumnHeader();
            btnBeklet = new Button();
            btnIptalEt = new Button();
            btnOnayla = new Button();
            btnYeniRezervasyon = new Button();
            Timer1 = new System.Windows.Forms.Timer(components);
            notifyIcon1 = new NotifyIcon(components);
            Timer2 = new System.Windows.Forms.Timer(components);
            btnKayitliMusteriler = new Button();
            SuspendLayout();
            // 
            // bunifuElipse1
            // 
            bunifuElipse1.ElipseRadius = 5;
            bunifuElipse1.TargetControl = this;
            // 
            // btnCikis
            // 
            btnCikis.FlatAppearance.BorderSize = 0;
            btnCikis.FlatStyle = FlatStyle.Flat;
            btnCikis.ImageIndex = 0;
            btnCikis.ImageList = ımageList2;
            btnCikis.Location = new Point(1221, 12);
            btnCikis.Name = "btnCikis";
            btnCikis.Size = new Size(67, 58);
            btnCikis.TabIndex = 4;
            btnCikis.UseVisualStyleBackColor = true;
            btnCikis.Click += btnCikis_Click;
            // 
            // ımageList2
            // 
            ımageList2.ColorDepth = ColorDepth.Depth32Bit;
            ımageList2.ImageStream = (ImageListStreamer)resources.GetObject("ımageList2.ImageStream");
            ımageList2.TransparentColor = Color.Transparent;
            ımageList2.Images.SetKeyName(0, "pngwing.com (9).png");
            // 
            // btnImg
            // 
            btnImg.FlatAppearance.BorderSize = 0;
            btnImg.FlatStyle = FlatStyle.Flat;
            btnImg.ImageIndex = 1;
            btnImg.ImageList = ımageList1;
            btnImg.Location = new Point(-4, -4);
            btnImg.Name = "btnImg";
            btnImg.Size = new Size(135, 131);
            btnImg.TabIndex = 3;
            btnImg.UseVisualStyleBackColor = true;
            // 
            // ımageList1
            // 
            ımageList1.ColorDepth = ColorDepth.Depth32Bit;
            ımageList1.ImageStream = (ImageListStreamer)resources.GetObject("ımageList1.ImageStream");
            ımageList1.TransparentColor = Color.Transparent;
            ımageList1.Images.SetKeyName(0, "kgm_logo.png");
            ımageList1.Images.SetKeyName(1, "KGM_logo.svg.png");
            // 
            // btnOdalar
            // 
            btnOdalar.BackColor = Color.Yellow;
            btnOdalar.FlatAppearance.BorderSize = 0;
            btnOdalar.FlatStyle = FlatStyle.Flat;
            btnOdalar.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnOdalar.Location = new Point(453, 13);
            btnOdalar.Name = "btnOdalar";
            btnOdalar.Size = new Size(220, 45);
            btnOdalar.TabIndex = 10;
            btnOdalar.Text = "Odalar";
            btnOdalar.UseVisualStyleBackColor = false;
            btnOdalar.Click += btnOdalar_Click;
            // 
            // btnRaporlar
            // 
            btnRaporlar.BackColor = Color.Yellow;
            btnRaporlar.FlatAppearance.BorderSize = 0;
            btnRaporlar.FlatStyle = FlatStyle.Flat;
            btnRaporlar.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnRaporlar.Location = new Point(679, 12);
            btnRaporlar.Name = "btnRaporlar";
            btnRaporlar.Size = new Size(220, 45);
            btnRaporlar.TabIndex = 9;
            btnRaporlar.Text = "Raporlar";
            btnRaporlar.UseVisualStyleBackColor = false;
            btnRaporlar.Click += btnRaporlar_Click;
            // 
            // btnRezervasyonlar
            // 
            btnRezervasyonlar.BackColor = Color.DarkOrange;
            btnRezervasyonlar.FlatAppearance.BorderColor = Color.Black;
            btnRezervasyonlar.FlatAppearance.BorderSize = 0;
            btnRezervasyonlar.FlatStyle = FlatStyle.Popup;
            btnRezervasyonlar.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnRezervasyonlar.Location = new Point(227, 12);
            btnRezervasyonlar.Name = "btnRezervasyonlar";
            btnRezervasyonlar.Size = new Size(220, 45);
            btnRezervasyonlar.TabIndex = 8;
            btnRezervasyonlar.Text = "Rezervasyonlar";
            btnRezervasyonlar.UseVisualStyleBackColor = false;
            // 
            // btnOnayBekleyen
            // 
            btnOnayBekleyen.FlatStyle = FlatStyle.Flat;
            btnOnayBekleyen.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnOnayBekleyen.Location = new Point(12, 135);
            btnOnayBekleyen.Name = "btnOnayBekleyen";
            btnOnayBekleyen.Size = new Size(185, 37);
            btnOnayBekleyen.TabIndex = 11;
            btnOnayBekleyen.Text = "Onay Bekleyen";
            btnOnayBekleyen.UseVisualStyleBackColor = true;
            btnOnayBekleyen.Click += btnOnayBekleyen_Click;
            // 
            // btnOnaylanan
            // 
            btnOnaylanan.BackColor = Color.DarkSeaGreen;
            btnOnaylanan.FlatAppearance.BorderSize = 0;
            btnOnaylanan.FlatStyle = FlatStyle.Flat;
            btnOnaylanan.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnOnaylanan.ForeColor = Color.Black;
            btnOnaylanan.Location = new Point(203, 135);
            btnOnaylanan.Name = "btnOnaylanan";
            btnOnaylanan.Size = new Size(185, 37);
            btnOnaylanan.TabIndex = 12;
            btnOnaylanan.Text = "Onaylanan";
            btnOnaylanan.UseVisualStyleBackColor = false;
            btnOnaylanan.Click += btnOnaylanan_Click;
            // 
            // btnGecmis
            // 
            btnGecmis.BackColor = Color.DarkSeaGreen;
            btnGecmis.FlatAppearance.BorderSize = 0;
            btnGecmis.FlatStyle = FlatStyle.Flat;
            btnGecmis.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnGecmis.ForeColor = Color.Black;
            btnGecmis.Location = new Point(394, 135);
            btnGecmis.Name = "btnGecmis";
            btnGecmis.Size = new Size(185, 37);
            btnGecmis.TabIndex = 13;
            btnGecmis.Text = "Geçmiş";
            btnGecmis.UseVisualStyleBackColor = false;
            btnGecmis.Click += btnGecmis_Click;
            // 
            // lstViewRezervasyonlar
            // 
            lstViewRezervasyonlar.BorderStyle = BorderStyle.None;
            lstViewRezervasyonlar.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader3, columnHeader4, columnHeader5, columnHeader6, columnHeader7, columnHeader8, columnHeader2, columnHeader9, columnHeader10, columnHeader11, columnHeader14 });
            lstViewRezervasyonlar.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Regular, GraphicsUnit.Point);
            lstViewRezervasyonlar.FullRowSelect = true;
            lstViewRezervasyonlar.GridLines = true;
            lstViewRezervasyonlar.Location = new Point(9, 180);
            lstViewRezervasyonlar.Name = "lstViewRezervasyonlar";
            lstViewRezervasyonlar.Size = new Size(1280, 400);
            lstViewRezervasyonlar.TabIndex = 14;
            lstViewRezervasyonlar.UseCompatibleStateImageBehavior = false;
            lstViewRezervasyonlar.View = View.Details;
            lstViewRezervasyonlar.SelectedIndexChanged += lstViewRezervasyonlar_SelectedIndexChanged;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Ad Soyad";
            columnHeader1.Width = 180;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Email";
            columnHeader3.Width = 145;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Telefon";
            columnHeader4.Width = 160;
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "Yetişkin Sayısı";
            columnHeader5.Width = 140;
            // 
            // columnHeader6
            // 
            columnHeader6.Text = "Çocuk Sayısı";
            columnHeader6.Width = 130;
            // 
            // columnHeader7
            // 
            columnHeader7.Text = "Kat";
            columnHeader7.Width = 65;
            // 
            // columnHeader8
            // 
            columnHeader8.Text = "Oda No";
            columnHeader8.Width = 82;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Giriş Tarihi";
            columnHeader2.Width = 135;
            // 
            // columnHeader9
            // 
            columnHeader9.Text = "Çıkış Tarihi";
            columnHeader9.Width = 135;
            // 
            // columnHeader10
            // 
            columnHeader10.Text = "Fiyat";
            columnHeader10.Width = 75;
            // 
            // columnHeader11
            // 
            columnHeader11.Text = "Rezervasyon Durumu";
            columnHeader11.Width = 170;
            // 
            // columnHeader14
            // 
            columnHeader14.Text = "id";
            columnHeader14.Width = 1;
            // 
            // btnBeklet
            // 
            btnBeklet.BackColor = Color.Turquoise;
            btnBeklet.FlatAppearance.BorderSize = 0;
            btnBeklet.FlatStyle = FlatStyle.Flat;
            btnBeklet.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnBeklet.ForeColor = Color.Black;
            btnBeklet.Location = new Point(762, 595);
            btnBeklet.Name = "btnBeklet";
            btnBeklet.Size = new Size(185, 37);
            btnBeklet.TabIndex = 17;
            btnBeklet.Text = "Beklet";
            btnBeklet.UseVisualStyleBackColor = false;
            btnBeklet.Click += btnBeklet_Click;
            // 
            // btnIptalEt
            // 
            btnIptalEt.BackColor = Color.Red;
            btnIptalEt.FlatAppearance.BorderSize = 0;
            btnIptalEt.FlatStyle = FlatStyle.Flat;
            btnIptalEt.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnIptalEt.ForeColor = Color.Black;
            btnIptalEt.Location = new Point(571, 595);
            btnIptalEt.Name = "btnIptalEt";
            btnIptalEt.Size = new Size(185, 37);
            btnIptalEt.TabIndex = 16;
            btnIptalEt.Text = "İptal Et";
            btnIptalEt.UseVisualStyleBackColor = false;
            btnIptalEt.Click += btnIptalEt_Click;
            // 
            // btnOnayla
            // 
            btnOnayla.BackColor = Color.Lime;
            btnOnayla.FlatAppearance.BorderSize = 0;
            btnOnayla.FlatStyle = FlatStyle.Flat;
            btnOnayla.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnOnayla.Location = new Point(380, 595);
            btnOnayla.Name = "btnOnayla";
            btnOnayla.Size = new Size(185, 37);
            btnOnayla.TabIndex = 15;
            btnOnayla.Text = "Onayla";
            btnOnayla.UseVisualStyleBackColor = false;
            btnOnayla.Click += btnOnayla_Click;
            // 
            // btnYeniRezervasyon
            // 
            btnYeniRezervasyon.BackColor = SystemColors.Highlight;
            btnYeniRezervasyon.FlatAppearance.BorderSize = 0;
            btnYeniRezervasyon.FlatStyle = FlatStyle.Flat;
            btnYeniRezervasyon.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Regular, GraphicsUnit.Point);
            btnYeniRezervasyon.ForeColor = Color.White;
            btnYeniRezervasyon.Location = new Point(1040, 135);
            btnYeniRezervasyon.Name = "btnYeniRezervasyon";
            btnYeniRezervasyon.Size = new Size(248, 37);
            btnYeniRezervasyon.TabIndex = 18;
            btnYeniRezervasyon.Text = "Yeni Rezervasyon Oluştur";
            btnYeniRezervasyon.UseVisualStyleBackColor = false;
            btnYeniRezervasyon.Click += btnYeniRezervasyon_Click;
            // 
            // Timer1
            // 
            Timer1.Interval = 1000;
            Timer1.Tick += Timer1_Tick;
            // 
            // notifyIcon1
            // 
            notifyIcon1.Text = "notifyIcon1";
            notifyIcon1.Visible = true;
            // 
            // Timer2
            // 
            Timer2.Interval = 100000;
            // 
            // btnKayitliMusteriler
            // 
            btnKayitliMusteriler.BackColor = Color.Yellow;
            btnKayitliMusteriler.FlatAppearance.BorderSize = 0;
            btnKayitliMusteriler.FlatStyle = FlatStyle.Flat;
            btnKayitliMusteriler.Font = new Font("Microsoft Sans Serif", 18.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnKayitliMusteriler.Location = new Point(905, 12);
            btnKayitliMusteriler.Name = "btnKayitliMusteriler";
            btnKayitliMusteriler.Size = new Size(220, 45);
            btnKayitliMusteriler.TabIndex = 19;
            btnKayitliMusteriler.Text = "Kayıtlı Müşteriler";
            btnKayitliMusteriler.UseVisualStyleBackColor = false;
            btnKayitliMusteriler.Click += btnKayitliMusteriler_Click;
            // 
            // rezervasyonlar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOrange;
            ClientSize = new Size(1300, 650);
            Controls.Add(btnKayitliMusteriler);
            Controls.Add(btnYeniRezervasyon);
            Controls.Add(btnBeklet);
            Controls.Add(btnIptalEt);
            Controls.Add(btnOnayla);
            Controls.Add(lstViewRezervasyonlar);
            Controls.Add(btnGecmis);
            Controls.Add(btnOnaylanan);
            Controls.Add(btnOnayBekleyen);
            Controls.Add(btnOdalar);
            Controls.Add(btnRaporlar);
            Controls.Add(btnRezervasyonlar);
            Controls.Add(btnCikis);
            Controls.Add(btnImg);
            FormBorderStyle = FormBorderStyle.None;
            Name = "rezervasyonlar";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "x";
            Load += Rezervasyonlar_Load;
            ResumeLayout(false);
        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Button btnCikis;
        private ImageList ımageList2;
        private Button btnImg;
        private ImageList ımageList1;
        private Button btnOdalar;
        private Button btnRaporlar;
        private Button btnRezervasyonlar;
        private Button btnOnayBekleyen;
        private Button btnGecmis;
        private Button btnOnaylanan;
        private ListView lstViewRezervasyonlar;
        private Button btnBeklet;
        private Button btnIptalEt;
        private Button btnOnayla;
        private Button btnYeniRezervasyon;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private ColumnHeader columnHeader6;
        private ColumnHeader columnHeader7;
        private ColumnHeader columnHeader8;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader9;
        public System.Windows.Forms.Timer Timer1;
        private NotifyIcon notifyIcon1;
        private ColumnHeader columnHeader10;
        private ColumnHeader columnHeader11;
        private System.Windows.Forms.Timer Timer2;
        private ColumnHeader columnHeader14;
        private Button btnKayitliMusteriler;
    }
}